<?php return array (
  'admin.post-index' => 'App\\Http\\Livewire\\Admin\\PostIndex',
  'admin.users-index' => 'App\\Http\\Livewire\\Admin\\UsersIndex',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);